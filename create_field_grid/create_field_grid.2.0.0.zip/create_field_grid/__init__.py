# -*- coding: utf-8 -*-
"""Create Field Grid - QGIS plugin entry point.

Licensed under the GNU General Public License v2 or later (see LICENSE).
"""


def classFactory(iface):
    """Called by QGIS when the plugin is loaded."""
    from .plugin import FieldGridPlugin
    return FieldGridPlugin(iface)
