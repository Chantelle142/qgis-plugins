# -*- coding: utf-8 -*-
"""Plugin class: registers the Processing provider and adds a toolbar button and a
Plugins menu entry that open the Create Field Grid dialog."""

import os

from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsApplication

try:
    from qgis.PyQt.QtGui import QAction      # Qt 6 (QGIS 4)
except ImportError:
    from qgis.PyQt.QtWidgets import QAction  # Qt 5 (QGIS 3)

from .provider import FieldToolsProvider, ICON_PATH

MENU = "&Field Tools"
ALGORITHM_ID = "fieldtools:createfieldgrid"


class FieldGridPlugin:

    def __init__(self, iface):
        self.iface = iface
        self.provider = None
        self.action = None

    def initProcessing(self):
        """Also called on its own by qgis_process (hasProcessingProvider=yes)."""
        if self.provider is None:
            self.provider = FieldToolsProvider()
            QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        self.initProcessing()
        self.action = QAction(QIcon(ICON_PATH), "Create Field Grid…", self.iface.mainWindow())
        self.action.setObjectName("createFieldGridAction")
        self.action.setToolTip("Create Field Grid: numbered soil sampling points per field")
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(MENU, self.action)

    def unload(self):
        if self.action is not None:
            self.iface.removePluginMenu(MENU, self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None
        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None

    def run(self):
        import processing
        processing.execAlgorithmDialog(ALGORITHM_ID)
