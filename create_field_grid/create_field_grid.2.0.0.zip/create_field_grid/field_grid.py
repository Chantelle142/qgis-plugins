# -*- coding: utf-8 -*-
"""
Create Field Grid  (QGIS Processing algorithm)  -  Phase 5 (v2 upgrades)

Creates soil sampling points: each polygon (field) is divided into square cells of
a chosen AREA (hectares or acres) and one numbered point is placed in each cell.
Install: as the "Create Field Grid" plugin (see README.md). It then appears in the
Processing Toolbox under  Field Tools > Create Field Grid, with a toolbar button too.
This file still works on its own: Processing Toolbox -> Scripts -> Add Script to
Toolbox... -> pick this file (it then appears directly under Scripts).

Licensed under the GNU General Public License v2 or later (see LICENSE).

Alignment (per field): the grid is rotated to follow the field's main edges
(or MBR / north / manual angle) and anchored on the longest edge (or bbox corner /
centred / optimised). Edge cells are clipped to the field; small ones are merged into
a neighbour by default (or dropped / kept).

Phase 5 adds: a layer with no projection is treated as EPSG:4326; most settings sit in
the dialog's Advanced parameters section; a limit on points per field based on its area
(with a small allowance for odd shapes); and a First number setting so numbering can
carry on across several runs. The full brief is SCOPE_v2.md (SCOPE.md is the old v1
record only).
"""

import math

from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureSink,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsPointXY,
    QgsProcessing,
    QgsFillSymbol,
    QgsMarkerSymbol,
    QgsPalLayerSettings,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingLayerPostProcessorInterface,
    QgsProcessingParameterDefinition,
    QgsSingleSymbolRenderer,
    QgsTextFormat,
    QgsVectorLayerSimpleLabeling,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterNumber,
    QgsRectangle,
    QgsUnitTypes,
    QgsWkbTypes,
)

# The "advanced parameter" flag moved in QGIS 3.36 (SCOPE_v2 section 3); support both names.
try:
    from qgis.core import Qgis
    ADVANCED = Qgis.ProcessingParameterFlag.Advanced          # QGIS 3.36+
except AttributeError:
    ADVANCED = QgsProcessingParameterDefinition.FlagAdvanced  # QGIS 3.28 - 3.34

M2_PER_HA = 10000.0
M2_PER_ACRE = 4046.8564224  # international acre
UNITS = [("ha", "Hectares", M2_PER_HA), ("ac", "Acres", M2_PER_ACRE)]

ORIENTATIONS = ["Auto - follow field edges", "Minimum bounding rectangle",
                "North-aligned", "Manual angle"]
ORIENT_AUTO, ORIENT_MBR, ORIENT_NORTH, ORIENT_MANUAL = range(4)
ANCHORS = ["Longest edge", "Bounding box corner", "Centred",
           "Optimised (most full cells)"]
ANCHOR_EDGE, ANCHOR_CORNER, ANCHOR_CENTRE, ANCHOR_OPT = range(4)
EDGE_MODES = ["Keep all edge cells", "Drop small edge cells",
              "Merge small edge cells into neighbour"]
EDGE_KEEP, EDGE_DROP, EDGE_MERGE = range(3)
EDGE_ANGLE_TOL = 8.0   # an edge counts as "on the grid axis" if within this many degrees

ODD_SHAPE_CONVEXITY = 0.85   # fields below this convexity count as odd-shaped (SCOPE_v2 5.4)
LIMIT_TARGET_SLACK = 0.05    # base limit ignores the first 5% of a cell: ceil(T - 0.05)
LIMIT_TIE_FRACTION = 0.05    # two shared borders within 5% of each other count as a tie

FULL_CELL_PCT = 99.9         # pct_full at or above this counts as a full cell
MAX_CELLS_PER_FIELD = 2000000  # safety stop for silly inputs (e.g. 0.0001 ha cells)


class GridStyler(QgsProcessingLayerPostProcessorInterface):
    """Gives the output layers a readable default look when they are added to the map:
    sample points as red dots labelled with their number, grid cells as outlines."""

    def __init__(self, kind):
        super().__init__()
        self.kind = kind  # "points" or "cells"

    def postProcessLayer(self, layer, context, feedback):
        if self.kind == "points":
            layer.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple(
                {"name": "circle", "color": "#e31a1c", "outline_color": "#ffffff",
                 "outline_width": "0.3", "size": "2.6"})))
            settings = QgsPalLayerSettings()
            settings.fieldName = "name"
            fmt = QgsTextFormat()
            fmt.setSize(9)
            fmt.buffer().setEnabled(True)
            fmt.buffer().setSize(1.0)
            settings.setFormat(fmt)
            layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
            layer.setLabelsEnabled(True)
        else:
            layer.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
                {"color": "0,0,0,0", "outline_color": "#1f78b4", "outline_width": "0.4"})))
        layer.triggerRepaint()
        return {}


class CreateFieldGrid(QgsProcessingAlgorithm):
    INPUT = "INPUT"
    SIZE = "SIZE"
    UNIT = "UNIT"
    FIRST = "FIRST"
    ORIENT = "ORIENT"
    ANGLE = "ANGLE"
    ANCHOR = "ANCHOR"
    EDGE = "EDGE"
    THRESH = "THRESH"
    LIMIT = "LIMIT"
    EXTRA_PCT = "EXTRA_PCT"
    FIELD_ID = "FIELD_ID"
    OUTPUT = "OUTPUT"
    CELLS = "CELLS"

    # ------------------------------------------------------------ metadata
    def tr(self, s):
        return QCoreApplication.translate("CreateFieldGrid", s)

    def createInstance(self):
        return CreateFieldGrid()

    def name(self):
        return "createfieldgrid"

    def displayName(self):
        return self.tr("Create Field Grid")

    # No group: the plugin's provider is already called "Field Tools", so the tool sits
    # directly under it (Field Tools > Create Field Grid) rather than one level deeper.
    def group(self):
        return ""

    def groupId(self):
        return ""

    def shortHelpString(self):
        return self.tr(
            "Creates soil sampling points: each field polygon is divided into square "
            "grid cells of a chosen AREA and one point is placed at the centre of "
            "each cell. Every point gets a unique number in the 'name' column (1, 2, 3... "
            "continuing from one field to the next), row by row, back and forth, so "
            "the numbers follow a walking route.\n\n"
            "ALIGNMENT\n"
            "Orientation - Auto follows the field's longest straight edges (best for "
            "most fields); Minimum bounding rectangle suits near-rectangular fields; "
            "North-aligned ignores the field shape; Manual uses your angle.\n"
            "Anchor - Longest edge puts a grid line exactly on the field's longest "
            "straight edge; Bounding box corner starts at a corner; Centred splits "
            "the leftover evenly on both sides; Optimised tries many small shifts and "
            "keeps the one with the most full cells.\n"
            "Small edge cells - tiny leftover pieces along the boundary would get a "
            "sample point of their own. 'Merge' (default) joins each one to the "
            "neighbour it shares the longest border with, 'Drop' removes it, "
            "'Keep all' leaves it. Merged cells are flagged in the 'merged' column.\n\n"
            "Cell size is the AREA of one cell, not its side length: 1 hectare gives "
            "100 m x 100 m cells, 1 acre gives cells of about 63.6 m x 63.6 m.\n\n"
            "Tick 'Selected features only' on the field layer to grid only the "
            "selected fields.\n\n"
            "Areas are always calculated in metres (the field's own UTM zone is used "
            "when the layer is in degrees), and the result is returned in the "
            "layer's original CRS.\n\n"
            "Cells on the field boundary are clipped to the field and the point is "
            "placed inside the clipped part. 'pct_full' shows how complete each "
            "cell is. Tick the optional 'Grid cells' output to see the cells.\n\n"
            "Limit points to the field's area: a field never gets more points than its "
            "area divided by the cell size (rounded up). Odd-shaped fields may get a few "
            "more (5% extra by default, rounded up). Every field gets at least one point.\n\n"
            "First number: the number given to the first point. Use it to carry on the "
            "numbering from an earlier run, so numbers stay unique across the farm. The "
            "log at the end of a run tells you which number to use next.\n\n"
            "Most settings are under Advanced parameters, and the defaults suit most "
            "fields. For a normal run, pick the layer, type the cell size and press Run.\n\n"
            "A layer with no projection is treated as EPSG:4326 (latitude/longitude)."
        )

    # ---------------------------------------------------------- parameters
    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT,
                self.tr("Field layer"),
                [QgsProcessing.TypeVectorPolygon],
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.SIZE,
                self.tr("Grid cell size (area of one cell)"),
                QgsProcessingParameterNumber.Double,
                defaultValue=1.0,
                minValue=0.0001,
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.UNIT,
                self.tr("Unit"),
                options=[u[1] for u in UNITS],
                defaultValue=0,
            )
        )

        # Advanced parameters (SCOPE_v2 section 3), in dialog order. Later steps add
        # their new parameters here too, through _add_advanced.
        self._add_advanced(
            QgsProcessingParameterNumber(
                self.FIRST,
                self.tr("First number"),
                QgsProcessingParameterNumber.Integer,
                defaultValue=1,
                minValue=1,
            )
        )
        self._add_advanced(
            QgsProcessingParameterEnum(
                self.ORIENT,
                self.tr("Grid orientation"),
                options=ORIENTATIONS,
                defaultValue=ORIENT_AUTO,
            )
        )
        self._add_advanced(
            QgsProcessingParameterNumber(
                self.ANGLE,
                self.tr("Manual angle in degrees, clockwise from north (only for 'Manual angle')"),
                QgsProcessingParameterNumber.Double,
                defaultValue=0.0,
                minValue=-360.0,
                maxValue=360.0,
            )
        )
        self._add_advanced(
            QgsProcessingParameterEnum(
                self.ANCHOR,
                self.tr("Grid anchor (where the grid lines start)"),
                options=ANCHORS,
                defaultValue=ANCHOR_EDGE,
            )
        )
        self._add_advanced(
            QgsProcessingParameterEnum(
                self.EDGE,
                self.tr("Small cells along the field edge"),
                options=EDGE_MODES,
                defaultValue=EDGE_MERGE,
            )
        )
        self._add_advanced(
            QgsProcessingParameterNumber(
                self.THRESH,
                self.tr("A clipped cell smaller than this % of a full cell counts as small"),
                QgsProcessingParameterNumber.Double,
                defaultValue=30.0,
                minValue=0.0,
                maxValue=100.0,
            )
        )
        self._add_advanced(
            QgsProcessingParameterBoolean(
                self.LIMIT,
                self.tr("Limit points to the field's area"),
                defaultValue=True,
            )
        )
        self._add_advanced(
            QgsProcessingParameterNumber(
                self.EXTRA_PCT,
                self.tr("Extra points allowed for odd-shaped fields (%)"),
                QgsProcessingParameterNumber.Double,
                defaultValue=5.0,
                minValue=0.0,
                maxValue=100.0,
            )
        )
        self._add_advanced(
            QgsProcessingParameterField(
                self.FIELD_ID,
                self.tr("Field ID attribute (copied to each cell)"),
                parentLayerParameterName=self.INPUT,
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                self.tr("Soil sample points"),
                QgsProcessing.TypeVectorPoint,
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.CELLS,
                self.tr("Grid cells (optional, for checking)"),
                QgsProcessing.TypeVectorPolygon,
                optional=True,
                createByDefault=False,
            )
        )

    def _add_advanced(self, param):
        """Add a parameter to the dialog's collapsible Advanced parameters section."""
        param.setFlags(param.flags() | ADVANCED)
        self.addParameter(param)

    # ------------------------------------------------------------- helpers
    @staticmethod
    def _is_metric_projected(crs):
        return (
            crs.isValid()
            and not crs.isGeographic()
            and crs.mapUnits() == QgsUnitTypes.DistanceMeters
        )

    @staticmethod
    def _utm_crs_for(geom, src_crs, tctx):
        """UTM CRS (WGS84) for the zone containing the geometry's centroid."""
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        c = geom.centroid()
        if c.isNull():
            c = QgsGeometry.fromPointXY(geom.boundingBox().center())
        c = QgsGeometry(c)
        c.transform(QgsCoordinateTransform(src_crs, wgs, tctx))
        p = c.asPoint()
        zone = int((p.x() + 180.0) // 6.0) + 1
        zone = max(1, min(60, zone))
        epsg = (32600 if p.y() >= 0 else 32700) + zone
        return QgsCoordinateReferenceSystem("EPSG:%d" % epsg)

    @staticmethod
    def _polygon_geometry(geom):
        """Keep only polygon parts of a geometry (None if nothing left)."""
        if geom is None or geom.isNull() or geom.isEmpty():
            return None
        if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.PolygonGeometry:
            return geom
        coll = geom.asGeometryCollection()
        polys = [g for g in coll
                 if QgsWkbTypes.geometryType(g.wkbType()) == QgsWkbTypes.PolygonGeometry]
        if not polys:
            return None
        out = polys[0]
        for g in polys[1:]:
            out = out.combine(g)
        return out

    # --------------------------------------------------------- the grid
    @staticmethod
    def _bearing90(dx, dy):
        """Compass bearing of a direction, folded into [0, 90): a square grid looks
        the same when turned 90 degrees, so N-S and E-W edges give the same value."""
        return math.degrees(math.atan2(dx, dy)) % 90.0

    @staticmethod
    def _largest_outer_ring(geom):
        """Exterior ring (list of QgsPointXY) of the largest polygon part."""
        polys = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
        best, best_area = None, -1.0
        for p in polys:
            if not p:
                continue
            a = QgsGeometry.fromPolygonXY(p).area()
            if a > best_area:
                best, best_area = p[0], a
        return best

    def _edges(self, geom, side):
        """Edges (x1, y1, x2, y2) of the simplified outer ring of the largest part.
        Simplifying first means GPS jitter and small wiggles do not count."""
        tol = max(1.0, 0.02 * side)
        simp = geom.simplify(tol)
        ring = None
        if simp is not None and not simp.isNull() and not simp.isEmpty():
            ring = self._largest_outer_ring(simp)
        if not ring or len(ring) < 4:
            ring = self._largest_outer_ring(geom)
        if not ring:
            return []
        return [(ring[i].x(), ring[i].y(), ring[i + 1].x(), ring[i + 1].y())
                for i in range(len(ring) - 1)]

    def _auto_angle(self, geom, side):
        """Dominant edge direction (0-90 deg, clockwise from north), length weighted."""
        segs = []
        for x1, y1, x2, y2 in self._edges(geom, side):
            dx, dy = x2 - x1, y2 - y1
            length = math.hypot(dx, dy)
            if length > 0:
                segs.append((self._bearing90(dx, dy), length))
        if not segs:
            return 0.0
        hist = [0.0] * 90
        for a, length in segs:
            hist[int(a) % 90] += length
        smooth = [sum(hist[(i + j) % 90] for j in range(-2, 3)) for i in range(90)]
        peak = smooth.index(max(smooth)) + 0.5
        # refine: circular mean (4x trick, because the period is 90) of edges near the peak
        sx = sy = 0.0
        for a, length in segs:
            d = ((a - peak + 45.0) % 90.0) - 45.0
            if abs(d) <= 3.0:
                sx += length * math.cos(math.radians(4.0 * a))
                sy += length * math.sin(math.radians(4.0 * a))
        if sx == 0.0 and sy == 0.0:
            return peak % 90.0
        return (math.degrees(math.atan2(sy, sx)) / 4.0) % 90.0

    def _mbr_angle(self, geom):
        """Direction of the minimum bounding rectangle's sides (0-90 deg)."""
        box = geom.orientedMinimumBoundingBox()[0]
        if box is None or box.isNull():
            return 0.0
        ring = box.asPolygon()[0]
        return self._bearing90(ring[1].x() - ring[0].x(), ring[1].y() - ring[0].y())

    def _field_angle(self, geom, side, orient, manual):
        if orient == ORIENT_AUTO:
            return self._auto_angle(geom, side)
        if orient == ORIENT_MBR:
            return self._mbr_angle(geom)
        if orient == ORIENT_MANUAL:
            return manual
        return 0.0

    def _edge_anchor(self, work, side):
        """
        Longest straight edge lying (nearly) along a grid axis, in the rotated frame.
        Returns ('h', y, x_start) for a horizontal edge or ('v', x, y_start) for a
        vertical one, or None if no edge lines up.
        """
        best, best_len = None, 0.0
        for x1, y1, x2, y2 in self._edges(work, side):
            dx, dy = x2 - x1, y2 - y1
            length = math.hypot(dx, dy)
            a = self._bearing90(dx, dy)
            if length > best_len and min(a, 90.0 - a) <= EDGE_ANGLE_TOL:
                best_len, best = length, (x1, y1, x2, y2)
        if best is None:
            return None
        x1, y1, x2, y2 = best
        if abs(x2 - x1) >= abs(y2 - y1):
            return ("h", (y1 + y2) / 2.0, min(x1, x2))
        return ("v", (x1 + x2) / 2.0, min(y1, y2))

    def _grid_field(self, geom, side, theta, anchor, small_pct, feedback):
        """
        geom   : field polygon in a metric CRS
        theta  : grid rotation (degrees clockwise from north)
        anchor : ANCHOR_EDGE / ANCHOR_CORNER / ANCHOR_CENTRE / ANCHOR_OPT
        small_pct : edge cells below this % of a full cell count as small (optimiser)
        returns: list of dicts {geom, row, col, area}
        """
        pivot = geom.centroid().asPoint()
        work = QgsGeometry(geom)
        if theta:
            work.rotate(-theta, pivot)  # rotate field so the grid is axis aligned

        bb = work.boundingBox()
        xmin, xmax, ymin, ymax = bb.xMinimum(), bb.xMaximum(), bb.yMinimum(), bb.yMaximum()

        # grid lines sit at x0 + i*side and y0 + j*side (any integer i, j)
        x0, y0 = xmin, ymin
        if anchor == ANCHOR_CENTRE:
            nx = max(1, int(math.ceil(bb.width() / side - 1e-9)))
            ny = max(1, int(math.ceil(bb.height() / side - 1e-9)))
            x0 = (xmin + xmax) / 2.0 - nx * side / 2.0
            y0 = (ymin + ymax) / 2.0 - ny * side / 2.0
        elif anchor in (ANCHOR_EDGE, ANCHOR_OPT):
            edge = self._edge_anchor(work, side)
            if edge is not None:
                kind, pos, start = edge
                if kind == "h":
                    y0, x0 = pos, start
                else:
                    x0, y0 = pos, start

        engine = QgsGeometry.createGeometryEngine(work.constGet())
        engine.prepareGeometry()

        if anchor == ANCHOR_OPT:
            x0, y0 = self._optimise_offset(work, engine, bb, x0, y0, side, small_pct, feedback)

        i_lo, i_hi, j_lo, j_hi = self._lattice(bb, x0, y0, side)
        if (i_hi - i_lo) * (j_hi - j_lo) > MAX_CELLS_PER_FIELD:
            raise QgsProcessingException(
                self.tr("This would create %d cells for one field. "
                        "Increase the cell size.") % ((i_hi - i_lo) * (j_hi - j_lo))
            )

        cells = []
        for j in range(j_lo, j_hi):
            if feedback.isCanceled():
                break
            r = j - j_lo
            ya, yb = y0 + j * side, y0 + (j + 1) * side
            for i in range(i_lo, i_hi):
                c = i - i_lo
                xa, xb = x0 + i * side, x0 + (i + 1) * side
                cell = QgsGeometry.fromRect(QgsRectangle(xa, ya, xb, yb))
                if not engine.intersects(cell.constGet()):
                    continue
                if engine.contains(cell.constGet()):
                    piece, area = cell, side * side
                else:
                    piece = self._polygon_geometry(cell.intersection(work))
                    if piece is None:
                        continue
                    area = piece.area()
                    if area < 1e-4:  # slivers from rounding, < 1 cm2
                        continue
                if theta:
                    piece.rotate(theta, pivot)
                cells.append({"geom": piece, "row": r, "col": c, "area": area,
                              "merged": False})
        return cells

    # ------------------------------------------------ Phase 3: optimiser
    @staticmethod
    def _lattice(bb, x0, y0, side):
        """Index range (i_lo, i_hi, j_lo, j_hi) of grid cells needed to cover bb."""
        i_lo = int(math.floor((bb.xMinimum() - x0) / side + 1e-9))
        i_hi = max(i_lo + 1, int(math.ceil((bb.xMaximum() - x0) / side - 1e-9)))
        j_lo = int(math.floor((bb.yMinimum() - y0) / side + 1e-9))
        j_hi = max(j_lo + 1, int(math.ceil((bb.yMaximum() - y0) / side - 1e-9)))
        return i_lo, i_hi, j_lo, j_hi

    def _count_cells(self, work, engine, bb, x0, y0, side, small_pct):
        """(full cells, small cells) for a grid starting at x0, y0."""
        i_lo, i_hi, j_lo, j_hi = self._lattice(bb, x0, y0, side)
        full = small = 0
        for j in range(j_lo, j_hi):
            ya, yb = y0 + j * side, y0 + (j + 1) * side
            for i in range(i_lo, i_hi):
                cell = QgsGeometry.fromRect(
                    QgsRectangle(x0 + i * side, ya, x0 + (i + 1) * side, yb))
                if not engine.intersects(cell.constGet()):
                    continue
                if engine.contains(cell.constGet()):
                    full += 1
                    continue
                # edge cell: same definition of 'full' as the output (>= FULL_CELL_PCT),
                # so a cell shaved by a tiny wiggle of the boundary still counts
                piece = cell.intersection(work)
                area = 0.0 if piece is None or piece.isNull() else piece.area()
                pct = 100.0 * area / (side * side)
                if pct >= FULL_CELL_PCT:
                    full += 1
                elif area >= 1e-4 and pct < small_pct:
                    small += 1
        return full, small

    def _optimise_offset(self, work, engine, bb, bx, by, side, small_pct, feedback):
        """
        Slide the grid in steps of side/20 (side/10 for very big fields) and keep the
        position with the most full cells; ties are broken by the fewest small edge
        cells. Offsets closest to the starting position are tried first.
        """
        n_est = (bb.width() / side + 1) * (bb.height() / side + 1)
        steps = 20 if n_est <= 1500 else 10
        offsets = sorted(
            ((a, b) for a in range(steps) for b in range(steps)),
            key=lambda ab: min(ab[0], steps - ab[0]) + min(ab[1], steps - ab[1]),
        )
        best = None  # (full cells, -small cells, x, y); ties keep the earliest offset
        for a, b in offsets:
            if feedback.isCanceled():
                break
            x, y = bx + a * side / steps, by + b * side / steps
            full, small = self._count_cells(work, engine, bb, x, y, side, small_pct)
            if best is None or (full, -small) > best[:2]:
                best = (full, -small, x, y)
        return best[2], best[3]

    # ------------------------------------------------ Phase 3: edge cells
    def _handle_small_cells(self, cells, mode, small_pct, cell_area, feedback, label):
        """Keep, drop or merge the clipped cells smaller than small_pct of a full cell."""
        def is_small(c):
            return 100.0 * c["area"] / cell_area < small_pct

        if mode == EDGE_KEEP or not any(is_small(c) for c in cells):
            return cells

        if mode == EDGE_DROP:
            kept = [c for c in cells if not is_small(c)]
            if not kept:  # never leave a field with no sample point at all
                return cells
            lost = sum(c["area"] for c in cells if is_small(c))
            feedback.pushInfo(self.tr("Field %s: dropped %d small edge cells (%.4f ha "
                                      "of the field is not covered)")
                              % (label, len(cells) - len(kept), lost / M2_PER_HA))
            return kept

        # merge: smallest piece first, into the neighbour it shares the longest border with
        cells = list(cells)
        stuck = set()
        n_merged = 0
        while True:
            smalls = [c for c in cells if is_small(c) and id(c) not in stuck]
            if not smalls:
                break
            s = min(smalls, key=lambda c: c["area"])
            best = self._find_neighbour(cells, s)
            if best is None:
                stuck.add(id(s))  # no neighbour (e.g. field smaller than one cell)
                continue
            self._absorb(best, s)
            cells.remove(s)
            n_merged += 1
        if n_merged:
            feedback.pushInfo(self.tr("Field %s: merged %d small edge cells into neighbours")
                              % (label, n_merged))
        return cells

    @staticmethod
    def _find_neighbour(cells, s, prefer_smaller=False):
        """
        The cell to merge cell s into: the neighbour that shares the longest border with
        it (None if s touches no other cell along a line). Used by the edge-cell merge
        (SCOPE_v2 5.3) and by the point limit (5.4).
        prefer_smaller=False : the longest border wins; on an exact tie the first one found.
        prefer_smaller=True  : borders within LIMIT_TIE_FRACTION (5%) of the longest count
                               as equal, and the smaller of those neighbours wins.
        """
        sbox = s["geom"].boundingBox()
        borders = []
        for o in cells:
            if o is s or not sbox.intersects(o["geom"].boundingBox()):
                continue
            shared = s["geom"].intersection(o["geom"])
            if shared is None or shared.isNull() or shared.isEmpty():
                continue
            length = shared.length()
            if length > 1e-6:
                borders.append((o, length))
        if not borders:
            return None
        longest = max(length for _, length in borders)
        if not prefer_smaller:
            return next(o for o, length in borders if length == longest)
        close = [o for o, length in borders if length >= longest * (1.0 - LIMIT_TIE_FRACTION)]
        return min(close, key=lambda o: o["area"])

    @staticmethod
    def _absorb(big, small):
        """Merge cell 'small' into cell 'big' (big keeps its own row and col)."""
        big["geom"] = big["geom"].combine(small["geom"])
        big["area"] += small["area"]
        big["merged"] = True

    # ------------------------------------------------ Phase 5: point limit
    @staticmethod
    def _convexity(geom):
        """
        Field area / area of its convex hull, from the OUTER ring(s) only, so holes do
        not count against it. For a multipart field the hull covers all the parts.
        """
        polys = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
        parts = [QgsGeometry.fromPolygonXY([p[0]]) for p in polys if p]
        if not parts:
            return 1.0
        hull = QgsGeometry.collectGeometry(parts).convexHull()
        hull_area = 0.0 if hull is None or hull.isNull() else hull.area()
        if hull_area <= 0.0:
            return 1.0
        return min(1.0, sum(p.area() for p in parts) / hull_area)

    @staticmethod
    def _point_limit(target, convexity, extra_pct):
        """
        SCOPE_v2 5.4: returns (base limit B, extra E, final limit L, odd_shape).
        B = max(1, ceil(T - 0.05)). Fields under ODD_SHAPE_CONVEXITY with B >= 2 may get
        E = ceil(B * extra_pct / 100) more points. A field with B = 1 always gets 1.
        """
        base = max(1, int(math.ceil(target - LIMIT_TARGET_SLACK)))
        odd = convexity < ODD_SHAPE_CONVEXITY
        extra = 0
        if odd and base >= 2 and extra_pct > 0:
            extra = int(math.ceil(base * extra_pct / 100.0 - 1e-9))
        return base, extra, base + extra, odd

    def _enforce_point_limit(self, cells, wgeom, cell_area, extra_pct, size_label,
                             feedback, label):
        """
        Point limit per field (SCOPE_v2 5.4), run after the edge-cell step. Merges the
        smallest cell into the neighbour it shares the longest border with until the field
        has no more cells than its limit. Never drops or splits cells.
        """
        target = wgeom.area() / cell_area
        convexity = self._convexity(wgeom)
        base, extra, limit, odd = self._point_limit(target, convexity, extra_pct)
        before = len(cells)

        cells = list(cells)
        stuck = set()
        while len(cells) > limit:
            free = [c for c in cells if id(c) not in stuck]
            if not free:
                break
            s = min(free, key=lambda c: c["area"])
            best = self._find_neighbour(cells, s, prefer_smaller=True)
            if best is None:
                stuck.add(id(s))  # no neighbour (e.g. a separate part): try the next smallest
                continue
            self._absorb(best, s)
            cells.remove(s)
        after = len(cells)

        if base < 2:
            shape = self.tr("base limit 1, no extra points")
        elif odd:
            shape = self.tr("odd shape, +%d allowed at %g%%") % (extra, extra_pct)
        else:
            shape = self.tr("compact, no extra points")
        points_after = self.tr("%d point") % after if after == 1 else self.tr("%d points") % after
        if after < before:
            tail = self.tr("%d cells merged down to %s") % (before, points_after)
        else:
            tail = self.tr("%s, nothing to merge") % points_after
        feedback.pushInfo(
            self.tr("Field %s: %.2f ha, target %.2f, convexity %.0f%% (%s), limit %d, %s.")
            % (label, wgeom.area() / M2_PER_HA, target, 100.0 * convexity, shape, limit, tail)
        )
        if after > limit:
            feedback.pushWarning(
                self.tr("Field %s: could not reduce %d points to the limit of %d, because the "
                        "remaining cells have no neighbour to merge into. The extra points "
                        "were kept.") % (label, after, limit)
            )
        if after < int(math.floor(target + 1e-6)):
            feedback.pushWarning(
                self.tr("Field %s: %d points for %.1f ha at %s cells. Coverage may be thin; "
                        "try a smaller cell size or another grid orientation.")
                % (label, after, wgeom.area() / M2_PER_HA, size_label)
            )
        return cells

    # ------------------------------------------------------------- run
    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, self.INPUT, context)
        if source is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.INPUT))

        size = self.parameterAsDouble(parameters, self.SIZE, context)
        unit_idx = self.parameterAsEnum(parameters, self.UNIT, context)
        unit_code, unit_name, m2_per_unit = UNITS[unit_idx]
        cell_area = size * m2_per_unit
        side = math.sqrt(cell_area)
        first_number = self.parameterAsInt(parameters, self.FIRST, context)
        orient = self.parameterAsEnum(parameters, self.ORIENT, context)
        manual_angle = self.parameterAsDouble(parameters, self.ANGLE, context)
        anchor = self.parameterAsEnum(parameters, self.ANCHOR, context)
        edge_mode = self.parameterAsEnum(parameters, self.EDGE, context)
        small_pct = self.parameterAsDouble(parameters, self.THRESH, context)
        limit_on = self.parameterAsBoolean(parameters, self.LIMIT, context)
        extra_pct = self.parameterAsDouble(parameters, self.EXTRA_PCT, context)
        id_field = self.parameterAsString(parameters, self.FIELD_ID, context)

        total = source.featureCount()
        if total == 0:
            raise QgsProcessingException(
                self.tr("No polygons to process. If 'Selected features only' is "
                        "ticked, select at least one field first.")
            )

        # Layer with no projection (SCOPE_v2 4.1): treat it as EPSG:4326. The input layer
        # is never changed; only the outputs carry EPSG:4326. This must run before the
        # output sinks are created, so a refused layer leaves no output behind.
        src_crs = source.sourceCrs()
        no_crs = not src_crs.isValid()
        if no_crs:
            src_crs = QgsCoordinateReferenceSystem("EPSG:4326")
            ext = source.sourceExtent()
            if not ext.isNull() and (ext.xMinimum() < -180.0 or ext.xMaximum() > 180.0
                                     or ext.yMinimum() < -90.0 or ext.yMaximum() > 90.0):
                raise QgsProcessingException(
                    self.tr("The field layer has no projection, and its coordinates are not "
                            "latitude/longitude (they look like metres). Set the correct "
                            "projection on the layer (Layer Properties → Source) and run "
                            "the tool again.")
                )
            feedback.pushWarning(
                self.tr("The field layer has no projection. It has been treated as "
                        "EPSG:4326 (WGS 84, latitude/longitude). If the points land in the "
                        "wrong place, set the layer's projection (Layer Properties → "
                        "Source) and run the tool again.")
            )

        # output fields
        fields = QgsFields()
        if id_field:
            src_f = source.fields().field(id_field)
            fields.append(QgsField("field_id", src_f.type(), len=src_f.length(),
                                   prec=src_f.precision()))
        else:
            fields.append(QgsField("field_id", QVariant.LongLong))
        for f in (
            QgsField("name", QVariant.Int),
            QgsField("row", QVariant.Int),
            QgsField("col", QVariant.Int),
            QgsField("area_ha", QVariant.Double),
            QgsField("area_ac", QVariant.Double),
            QgsField("pct_full", QVariant.Double),
            QgsField("is_full", QVariant.Bool),
            QgsField("merged", QVariant.Bool),
            QgsField("grid_angle", QVariant.Double),
            QgsField("target_size", QVariant.String),
        ):
            fields.append(f)

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT, context, fields,
            QgsWkbTypes.Point,
            src_crs,
        )
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))

        cell_sink, cell_dest = self.parameterAsSink(
            parameters, self.CELLS, context, fields,
            QgsWkbTypes.MultiPolygon,
            src_crs,
        )  # None when the optional cell-polygon output is skipped

        tctx = context.transformContext()
        metric_src = self._is_metric_projected(src_crs)
        target_label = "%s %s" % (("%g" % size), unit_code)

        feedback.pushInfo(
            self.tr("Cell area %s = %.2f m2 (side %.3f m)") % (target_label, cell_area, side)
        )

        n_cells = 0
        for i, feat in enumerate(source.getFeatures()):
            if feedback.isCanceled():
                break
            feedback.setProgress(100.0 * i / total)

            geom = feat.geometry()
            if geom is None or geom.isNull() or geom.isEmpty():
                feedback.pushWarning(self.tr("Feature %s has no geometry - skipped.") % feat.id())
                continue

            # to a metric working CRS
            if metric_src:
                work_crs = src_crs
                wgeom = QgsGeometry(geom)
            else:
                work_crs = self._utm_crs_for(geom, src_crs, tctx)
                wgeom = QgsGeometry(geom)
                wgeom.transform(QgsCoordinateTransform(src_crs, work_crs, tctx))

            if not wgeom.isGeosValid():
                fixed = wgeom.makeValid()
                if fixed is None or fixed.isNull():
                    feedback.pushWarning(self.tr("Feature %s is invalid and could not be "
                                                 "repaired - skipped.") % feat.id())
                    continue
                feedback.pushWarning(self.tr("Feature %s had invalid geometry; repaired.") % feat.id())
                wgeom = self._polygon_geometry(fixed)
                if wgeom is None:
                    continue

            field_val = feat[id_field] if id_field else feat.id()
            theta = self._field_angle(wgeom, side, orient, manual_angle)
            cells = self._grid_field(wgeom, side, theta, anchor, small_pct, feedback)
            cells = self._handle_small_cells(cells, edge_mode, small_pct, cell_area,
                                             feedback, field_val)
            if limit_on:  # point limit (SCOPE_v2 5.4): after the edge cells, before numbering
                cells = self._enforce_point_limit(cells, wgeom, cell_area, extra_pct,
                                                  target_label, feedback, field_val)

            back = None
            if not metric_src:
                back = QgsCoordinateTransform(work_crs, src_crs, tctx)

            # walking order: row by row, back and forth (serpentine)
            cells.sort(key=lambda c: (c["row"], c["col"] if c["row"] % 2 == 0 else -c["col"]))
            n_full = 0
            covered = 0.0
            for c in cells:
                number = first_number + n_cells  # running number, unique across all fields
                n_cells += 1
                pct = 100.0 * c["area"] / cell_area
                is_full = pct >= FULL_CELL_PCT and not c["merged"]
                n_full += 1 if is_full else 0
                covered += c["area"]

                # sample point: centre of the (clipped) cell, always inside it
                pt = c["geom"].centroid()
                if pt.isNull() or not c["geom"].contains(pt):
                    pt = c["geom"].pointOnSurface()
                poly_geom = c["geom"]
                if back is not None:
                    pt = QgsGeometry(pt)
                    pt.transform(back)
                    poly_geom = QgsGeometry(poly_geom)
                    poly_geom.transform(back)

                f = QgsFeature(fields)
                f.setGeometry(pt)
                f.setAttributes([
                    field_val,
                    number,
                    c["row"] + 1,
                    c["col"] + 1,
                    round(c["area"] / M2_PER_HA, 4),
                    round(c["area"] / M2_PER_ACRE, 4),
                    round(pct, 1),
                    is_full,
                    c["merged"],
                    round(theta, 2),
                    target_label,
                ])
                sink.addFeature(f, QgsFeatureSink.FastInsert)
                if cell_sink is not None:
                    fc = QgsFeature(f)
                    fc.setGeometry(poly_geom)
                    cell_sink.addFeature(fc, QgsFeatureSink.FastInsert)
            feedback.pushInfo(
                self.tr("Field %s: angle %.2f deg, %d sample points (%d full cells, "
                        "%d partial), %.4f ha covered")
                % (field_val, theta, len(cells), n_full, len(cells) - n_full,
                   covered / M2_PER_HA)
            )

        feedback.setProgress(100)
        if n_cells:
            last_number = first_number + n_cells - 1
            feedback.pushInfo(
                self.tr("Done: %d sample points created, numbered %d to %d. To continue the "
                        "numbering in another run, set First number to %d.")
                % (n_cells, first_number, last_number, last_number + 1)
            )
        else:
            feedback.pushInfo(self.tr("Done: %d sample points created.") % n_cells)
        result = {self.OUTPUT: dest_id}
        if cell_sink is not None:
            result[self.CELLS] = cell_dest

        # default styling when the layers are loaded into the project (keep references:
        # QGIS does not own the post-processor objects)
        self._stylers = []
        for key, kind in ((dest_id, "points"), (cell_dest if cell_sink is not None else None,
                                                "cells")):
            if key and context.willLoadLayerOnCompletion(key):
                styler = GridStyler(kind)
                self._stylers.append(styler)
                context.layerToLoadOnCompletionDetails(key).setPostProcessor(styler)
        return result
