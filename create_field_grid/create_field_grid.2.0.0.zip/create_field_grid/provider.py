# -*- coding: utf-8 -*-
"""Processing provider: the "Field Tools" group in the Processing Toolbox."""

import os

from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProcessingProvider

from .field_grid import CreateFieldGrid

ICON_PATH = os.path.join(os.path.dirname(__file__), "icon.png")


class FieldToolsProvider(QgsProcessingProvider):

    def loadAlgorithms(self):
        self.addAlgorithm(CreateFieldGrid())

    def id(self):
        # Algorithm IDs become "fieldtools:<name>", e.g. fieldtools:createfieldgrid
        return "fieldtools"

    def name(self):
        return "Field Tools"

    def longName(self):
        return self.name()

    def icon(self):
        return QIcon(ICON_PATH)
